# You Spin Me Round Robin

TODO

## Building

```shell
TODO
command "make" 
```

## Running

cmd for running TODO
```shell
TODO
command "./rr processes.txt 3" 
```

results TODO
```shell
TODO
average waiting time : 7.00
average response time : 2.75
```

## Cleaning up

```shell
TODO
command "make clean"
```
