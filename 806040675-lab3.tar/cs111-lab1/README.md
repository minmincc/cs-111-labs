## UID: 806040675

## Pipe Up

One sentence description
The pipe program replicates the functionality of the pipe (|) operator in shells, allowing users to chain multiple commands where the output of one command serves as the input to the next, by creating child processes for each command and setting up pipes between them.

## Building

Explain briefly how to build your program
build instruction : make

## Running

Show an example run of your program, using at least two additional arguments, and what to expect
running instruction: ./pipe ls cat wc

## Cleaning up

Explain briefly how to clean up all binary files
removing instruction: make clean
